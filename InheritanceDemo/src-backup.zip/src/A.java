
public class A {
	int x = 10;
	int z = 20;
	
	A() {}
	
	int getZ() {
		return z;
	}
}
