
public class Employee extends Person {
	
	String employeeId;
	
	Employee() {
		System.out.println("Employee class default constructor");
	}

}
