
public class Customer extends Person {
	String customerId;
	
	Customer() {
		super();
		System.out.println("Customer class default constructor");
		firstName = "akjsdhgf";
	}
}
