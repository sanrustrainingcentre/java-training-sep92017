
public class Person extends java.lang.Object {

	String firstName;
	String lastName;
	int age;
	char gender;//'M' or 'F' or 'm' or 'f'
	
	Person() {
		super();//by default JVM inserts 'super()' call in every constructor
		System.out.println("Person class default constructor");
	}
}
