
public class PersonDemo {

	public static void main(String[] args) {
		Customer customer = new Customer();
	}

}
